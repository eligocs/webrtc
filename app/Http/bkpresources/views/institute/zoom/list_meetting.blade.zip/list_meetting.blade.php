@extends('institute.layouts.app')
@section('page_heading', 'Live Lecture')
@section('content')
    <style>
        form {
            display: block;
            margin: 20px auto;
            background: #eee;
            border-radius: 10px;
            padding: 15px
        }

        .progress {
            height: 20px;
            position: relative;
            width: 400px;
            border: 1px solid #ddd;
            padding: 1px;
            border-radius: 3px;
        }

        .bar {
            background-color: #B4F5B4;
            width: 0%;
            height: 20px;
            border-radius: 3px;
        }

        .percent {
            position: absolute;
            display: inline-block;
            top: 3px;
            left: 48%;
        }

        i.fa.fa-pencil {
            color: #644699;
            font-size: 20px;
        }

        i.fa.fa-trash {
            color: #bd1f1f;
            font-size: 20px;
        }

        i.fa.fa-arrow-left,
        i.fa.fa-arrow-right {
            color: white;
            background: #644699;
            padding: 18px;
            border-radius: 28px;
        }

        .custom-arrows {
            display: flex;
            justify-content: center;
        }

        .custom-arrows1 {
            display: flex;
        }

        /* button#submit_meeting {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            border: none;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        } */

    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    {{-- @php
    dd($list_meeting);
    @endphp --}}
    <div class="container-fluid">
        <div class="card-box position-relative">
            <h3 class="heading-title m-0 text-center heading">Live Lecture</h3>
            <a href="{{ url('institute/create') }}" class="btn-theme btn-style add_lecture-btn" data-toggle="modal"
                data-target="#lectureModal">Create
                Lecture</a>
        </div>
        @if (count($list_meeting) > 0)
            @foreach ($list_meeting as $list)
                <div class="card-box">
                    <div class="table-responsive">
                        <h4 class=" mt-0 mb-3 text-center fw-100">Live Lecture</h4>
                        <table class="table table-bordered mb-0 package-table">
                            <thead>
                                <tr>
                                    <th style="width: 5%;">
                                        <h4 class="header-title m-0 text-center heading">Sr.no</h4>
                                    </th>
                                    <th style="width: 15%;">
                                        <h4 class="header-title m-0 text-center heading">Topic Name</h4>
                                    </th>
                                    <th style="width: 15%;">
                                        <h4 class="header-title m-0 text-center heading">Meeting Date</h4>
                                    </th>
                                    <th style="width: 5%;">
                                        <h4 class="header-title m-0 text-center heading">Duration</h4>
                                    </th>
                                    {{-- <th style="width: 5%;">
                                    <h4 class="header-title m-0 text-center heading">Password</h4>
                                </th> --}}
                                    <th style="width: 45%;">
                                        <h4 class="header-title m-0 text-center heading">Join Url</h4>
                                    </th>
                                    <td style="width: 20%">
                                        Action
                                    </td>
                                </tr>
                            </thead>


                            <tbody>
                                <tr>
                                    <td scope="row" style="width: 5%;">{{ $list->id }}</td>
                                    <td style="width: 15%;">{{ $list->topic_name }}</td>
                                    <td>{{ date('Y-m-d', strtotime($list->date)) }}</td>
                                    <td style="width: 5%;">
                                        {{ $list->duration }}
                                    </td>
                                    {{-- <td style="width: 15%;">
                                    {{ $list->password }}
                                </td> --}}
                                    <td style="width: 45%;overflow-wrap: anywhere;">
                                        @php
                                            $join_link = get_browser_join_links($list->meeting_id, $list->password);
                                        @endphp
                                        <a target='__blank' title='Join Now' href="{{ $join_link ? $join_link : '' }}"><i
                                                class="fa fa-video-camera" aria-hidden="true"></i></a>
                                    </td>
                                    <td style="width: 20%;">
                                        <a class="edit_meet" data-id='{{ $list->meeting_id }}'><i class="fa fa-pencil"
                                                aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;
                                        {{-- <a class=" edit_meet" data-id='{{ $list->meeting_id }}'><i class="fa fa-pencil"
                                                aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp; --}}
                                        <a href="" class="text-reds deleteLecture" data-id='{{ $list->meeting_id }}'><i
                                                class='fa fa-trash' id="delete_meeting"></i></a>
                                    </td>
                                </tr>
                            </tbody>

                        </table>
                    </div>
                </div>
            @endforeach
        @else
            <tr>
                <td colspan="8">No upcoming meeting</td>
            </tr>
        @endif
    </div>

    <!-- Create Modal -->
    <div class="modal fade" id="lectureModal" tabindex="-1" role="dialog" aria-labelledby="lectureModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="lectureModalLabel"> Create Meetings</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="card-box">
                        <form role="form" id='lectureForm'>
                            @csrf
                            <input name='last_id' class='last_id' id="id" value='' type='hidden'>
                            <div class='inputFields'>
                                <div class="form-group">
                                    <label for="lecture_name">Topic Name*</label>
                                    <input type="text" class="form-control" id="topic_name" name=" topic_name"
                                        value="{{ old('topic_name') }}" required>
                                </div>
                                <div class="form-group">
                                    <label for="lecture_date">Lecture Date*</label>
                                    <input type="text"
                                        value='{{ isset($meeting->start_time) ? $meeting->start_time : '' }}'
                                        class="form-control" required id="datetimepicker" name="start_time">
                                </div>
                                <div class="form-group">
                                    <label for="duration">Duration*</label>
                                    <input type="number" class="form-control" id="duration" aria-label="file example"
                                        name="duration" value="{{ old('duration') }}" required>
                                </div>
                                {{-- <div class="form-group">
                                    <label for="duration">Schedule*</label>
                                    <input type="number" class="form-control" aria-label="file example" id="schedule"
                                        name="schedule" autocomplete="off" value="{{ old('schedule') }}" required>
                                </div> --}}
                                <div class="form-group">
                                    <label for="duration">Password*</label>
                                    <input type="password" class="form-control" aria-label="file example" id="password"
                                        name="password" autocomplete="off" required>
                                </div>
                                <div class="form-group custom-arrows">
                                    <button type="submit" name="singlebutton" id="create_meeting" class="btn btn-primary">
                                        Create</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!----Edit form model --------->
    <!-- Modal -->
    <div class="modal fade" id="EditModel" tabindex="-1" role=" dialog" aria-labelledby="lectureModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="lectureModalLabel"> Edit Meetings</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="card-box">
                        <form role="form" id='lectureForm'>
                            @csrf
                            <input name='last_id' id="hiddenId" class='last_id' value=''
                                type='hidden'>
                            <div class='inputFields'>
                                <div class="form-group">
                                    <label for="lecture_name">Topic Name*</label>
                                    <input type="text" class="form-control" id="topic" name=" topic_name"
                                        value="" required>
                                </div>
                                <div class="form-group">
                                    <label for="lecture_date">Lecture Date*</label>
                                    <input type="text" value='' class="form-control" required
                                        id="datetimepic" name="start_time">
                                </div>
                                <div class="form-group">
                                    <label for="duration">Duration*</label>
                                    <input type="number" class="form-control" id="durati" aria-label="file example"
                                        name="duration" value="" required>
                                </div>
                                <div class="form-group">
                                    <label for="duration">Password*</label>
                                    <input type="password" class="form-control" aria-label="file example" id="pass"
                                        name="password" autocomplete="off" value="" required>
                                </div>
                                <div class="form-group custom-arrows">
                                    <button type="submit" name="singlebutton" id="edit_meeting_button"
                                        class="btn btn-primary">
                                        Edit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    {{-- dateTime Cdn --}}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.7.14/js/bootstrap-datetimepicker.min.js">
    </script>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker-standalone.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.7.14/css/bootstrap-datetimepicker.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#create_meeting").on('click', function(e) {
                e.preventDefault();
                var topic_name = $("#topic_name").val();
                var date = $("#datetimepicker").val();
                var duration = $("#duration").val();
                // var schedule = $("#schedule").val();
                var password = $("#password").val();
                if (topic_name != '' && date != '' && duration != '' && password != '') {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

                        },
                        url: "/institute/Meeting",
                        type: "POST",
                        data: {
                            topic_name: topic_name,
                            date: date,
                            duration: duration,
                            password: password,
                        },
                        caches: false,
                        success: function(dataResult) {
                            var dataResult = JSON.parse(dataResult);
                            if (dataResult.statusCode == 201) {
                                Swal.fire(
                                    'success!',
                                    'Done, Meeting Created!',
                                    'success'
                                )
                                setTimeout(() => {
                                    window.location.reload();
                                }, 5000);

                            } else {
                                if (dataResult.statusCode == 300) {
                                    Swal.fire(
                                        'Error!',
                                        'A maximum of {rateLimitNumber} meetings can be created/updated for a single user in one day.',
                                        'error'
                                    )
                                } else {
                                    if (dataResult.statusCode == 400) {
                                        Swal.fire(
                                            'Error!',
                                            'Pless Enter correct date!',
                                            'error'
                                        )
                                    }
                                }

                            }
                        }

                    })

                } else {
                    Swal.fire(
                        'Error!',
                        'All field are Required!',
                        'error'
                    )

                }
            });

            $('.deleteLecture').click(function(e) {
                e.preventDefault();
                var id = $(this).data('id');
                console.log(id);

                swal({
                        title: "Are you sure?",
                        text: "Once deleted, you will not be able to recover!",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    })
                    .then((willDelete) => {
                        if (willDelete) {
                            $.ajax({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                url: "/institute/deleteMeeting/" + id,
                                method: "post",
                                data: {
                                    id: id
                                },
                                success: function(response) {
                                    if (response.status = true) {
                                        swal("Lecture deleted successfully", {
                                            icon: "success",
                                        });
                                        setTimeout(() => {
                                            window.location.reload();
                                        }, 5000);
                                    } else {
                                        swal("Something wend wrong,try again later !!!");
                                    }
                                }
                            });
                        }
                    });
            });


            $('.edit_meet').click(function() {
                var meeting_id = $(this).data('id');
                var getid = $('#hiddenId').val('');
                var topic_name = $("#topic").val('');
                var date = $("#datetimepic").val('');
                var duration = $("#durati").val('');
                var password = $("#pass").val('');
                var id = $("#id").val('');
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

                    },
                    url: "/institute/getMeeting/" + meeting_id,
                    type: "POST",
                    data: {
                        meeting_id: meeting_id,

                    },
                    caches: false,
                    success: function(dataResult) {
                        console.log(dataResult);
                        if (dataResult.status) {

                            $("#EditModel").modal('show');
                            var meetingId = $('#hiddenId').val(dataResult.data.meeting_id);
                            var topic_name = $('#topic').val(dataResult.data.topic_name);
                            var date = $('#datetimepic').val(dataResult.data.date);
                            var duration = $('#durati').val(dataResult.data.duration);
                            var password = $('#pass').val(dataResult.data.password);


                        }

                        // response_return_meeting(meeting_id, topic_name, date, duration, password);
                    }
                })
            });



            $("#edit_meeting_button").on('click', function(e) {
                e.preventDefault();
                var id = $("#hiddenId").val();
                var topic_name = $("#topic").val();
                var date = $("#datetimepic").val();
                var duration = $("#durati").val();
                var password = $("#password").val();
                if (topic_name != '' && date != '' && duration != '' && password != '') {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr(
                                'content')

                        },
                        url: "/institute/editMeeting/" + id,
                        type: "POST",
                        data: {
                            id: id,
                            topic_name: topic_name,
                            date: date,
                            duration: duration,
                            password: password,
                        },
                        caches: false,
                        success: function(dataResult) {
                            var dataResult = JSON.parse(dataResult);
                            if (dataResult.statusCode == 200) {
                                Swal.fire(
                                    'success!',
                                    'Done, Meeting Updated!',
                                    'success'
                                )
                                setTimeout(() => {
                                    window.location.reload();
                                }, 5000);

                            } else {
                                if (dataResult.statusCode == 400) {
                                    Swal.fire(
                                        'Error!',
                                        'Meeting not updated',
                                        'error'
                                    )
                                    // } else {
                                    //     if (dataResult.statusCode == 400) {
                                    //         Swal.fire(
                                    //             'Error!',
                                    //             'Pless Enter correct date!',
                                    //             'error'
                                    //         )
                                    //     }
                                }

                            }
                        }

                    })

                } else {
                    Swal.fire(
                        'Error!',
                        'All field are Required!',
                        'error'
                    )

                }
            });

        });

        $("#datetimepicker").datetimepicker({
            // format: 'YYYY-MM-DD HH:mm A',
            format: 'YYYY-MM-DD hh:mm A',
            stepping: 15,

        });

        $("#datetimepic").datetimepicker({
            // format: 'YYYY-MM-DD HH:mm A',
            format: 'YYYY-MM-DD hh:mm A',
            stepping: 15,

        });
    </script>

@endsection
